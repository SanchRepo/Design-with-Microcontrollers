/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
// Gradually change compare value to turn the LED from fully Red to fully Green
#include "project.h"


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    PWM_Start();
    
    float dec = 10000*0.01;
    float val = 10000;

    for(;;)
    {
        PWM_WriteCompare(val);
        CyDelay(50);
        if (val <= 0) {
            val = 10000;
        }
        val = val-dec;
    }
}

/* [] END OF FILE */
