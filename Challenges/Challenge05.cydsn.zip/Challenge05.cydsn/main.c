/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/* **Add a third flip flop to light up the LED in the following sequence of 8 colors
OFF, RED, GREEN, YELLOW, BLUE, PURPLE, CYAN, WHITE */

#include "project.h"


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

  

    for(;;)
    {
        /*Pin_Red_Write( ~ Pin_SW2_Read() );*/
        
    }
}

/* [] END OF FILE */
