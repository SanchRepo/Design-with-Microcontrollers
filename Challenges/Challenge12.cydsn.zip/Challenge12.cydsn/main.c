/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/* 12	Use UARTGetChar and UARTPutChar functions to accept mixed case input from PuTTy or Tera Term
and display after converting the text to all upper case after each character is typed */
#include "project.h"
#include "ctype.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    UART_Start();
    
    for(;;)
    {
        UART_UartPutChar((char)toupper(UART_UartGetChar()));
    }
}

/* [] END OF FILE */
