/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

int main(void)
{
    uint16 buttval0;
    uint16 buttval1;
    uint16 oldbutt0 = 0xFFFF;
    uint16 oldbutt1 = 0xFFFF;
    
    char msg[20];
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    UART_Start();
    CapSense_Start();
    CapSense_InitializeAllBaselines();
    CapSense_ScanEnabledWidgets();
    
    
    for(;;)
    {
        /* Place your application code here. */
        if(! CapSense_IsBusy() ) {
            buttval0 = CapSense_CheckIsWidgetActive(CapSense_BUTTON0__BTN);
            buttval1 = CapSense_CheckIsWidgetActive(CapSense_BUTTON1__BTN);
            
            if (buttval0 != 0xFFFF && buttval0 != oldbutt0) {
                if (buttval0 == 1) {
                    sprintf(msg, "LEFT pressed");   
                    UART_UartPutString(msg);
                }
                if (buttval0 == 0) {
                    sprintf(msg, "LEFT released");   
                    UART_UartPutString(msg);
                }                
                oldbutt0 = buttval0;
            }
            
            if (buttval1 != 0xFFFF && buttval1 != oldbutt1) {
                if (buttval1 == 1) {
                    sprintf(msg, "RIGHT pressed");   
                    UART_UartPutString(msg);
                }
                if (buttval1 == 0) {
                    sprintf(msg, "RIGHT released");
                    UART_UartPutString(msg);
                }   
                oldbutt1 = buttval1;
            }
            CapSense_UpdateEnabledBaselines();
            CapSense_ScanEnabledWidgets();
        }
    }
}

/* [] END OF FILE */
