#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define Digital__DISABLED 1u /* Digital */
#define ADC__DISABLED 1u /* ADC */
#define CapSense__DISABLED 1u /* CapSense */
#define DAC__DISABLED 1u /* DAC */
#define LCD__DISABLED 1u /* LCD */
#define System__DISABLED 1u /* System */

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
