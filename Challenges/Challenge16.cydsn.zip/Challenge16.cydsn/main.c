/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
CY_ISR(Pin_SW2_Handler)
{
    Pin_SW2_ClearInterrupt();
}    

int main()
{
    CyGlobalIntEnable;      /* Enable global interrupts */
    
  
    
    UART_Start();
    
    Pin_SW2_Int_StartEx( Pin_SW2_Handler);
    
    for(;;)
    {
       UART_UartPutString( "Awake...\r\n");
       CyDelay( 5000 );
       UART_UartPutString( "Sleeping...\r\n");
        
       CySysPmSleep();
    
    }
}
