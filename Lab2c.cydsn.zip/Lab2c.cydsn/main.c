/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "string.h"
#include "stdio.h"
int second = 0; int prev = 1;
int minute = 0;
int hour = 0;
int s = 0;
char hh[2],mm[2],ss[2];
char format[2];
char time[8];


CY_ISR(UART_Handler){
    char msg;
    msg = UART_UartGetChar();
    if(msg == 'c') {
        ss[0] = '\0';
        ss[1] = '\0';
        mm[0] = '\0';
        mm[1] = '\0';
        hh[0] = '\0';
        hh[1] = '\0';
        UART_UartPutString("Seconds: ");
        while (!ss[0] || ss[0] - '0' > 5 || !isdigit(ss[0])) {
            ss[0] = UART_UartGetChar();
        }
        UART_UartPutChar(ss[0]);
        while (!ss[1] || !isdigit(ss[1])) {
            ss[1] = UART_UartGetChar();
        }
        UART_UartPutChar(ss[1]);
        CyDelay(250);
        
        UART_UartPutString("\r\nMinutes: ");
        while (!mm[0] || mm[0] - '0' > 5 || !isdigit(mm[0])) {
            mm[0] = UART_UartGetChar();
        }
        UART_UartPutChar(mm[0]);
        while (!mm[1] || !isdigit(mm[1])) {
            mm[1] = UART_UartGetChar();
        }
        UART_UartPutChar(mm[1]);
        CyDelay(250);
        
        UART_UartPutString("\r\nHours: ");
        while (!hh[0] || hh[0] - '0' > 2 || !isdigit(hh[0])) {
            hh[0] = UART_UartGetChar();
        }
        UART_UartPutChar(hh[0]);
        while (!hh[1] || !isdigit(hh[1])) {
            hh[1] = UART_UartGetChar();
        }
        UART_UartPutChar(hh[1]);
        CyDelay(500);
        
        second = 10*(ss[0] - '0')+(ss[1] - '0');
        minute = 10*(mm[0] - '0')+(mm[1] - '0');
        hour = 10*(hh[0] - '0')+(hh[1] - '0');
        UART_UartPutString("\r\n");
    }
    UART_ClearRxInterruptSource(UART_GetRxInterruptSource());
}

CY_ISR(Timer_Handler) {
    s = s + 1;
    if (s == 4000) {
        second = second + 1;
        if (second == 60) {
            second = 0;
            minute = minute + 1;
            if (minute == 60) {
                minute = 0;
                hour = hour + 1;
                if(hour == 24) {
                    hour = 0;
                    minute = 0;
                    second = 0;
                }
            }
        }
    s = 0;
    }
}

int main(void)

{
    CyGlobalIntDisable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    UART_Int_Start();
    UART_Int_SetVector(UART_Handler);
    
    Timer_Int_Start();
    Timer_Int_SetVector(Timer_Handler);
    CyGlobalIntEnable;
    
    
    UART_Start();    
    Timer_1_Start();
    
    
    for(;;)
    {
        if (prev != second) {
            sprintf(time,"%02d:%02d:%02d\r\n",hour,minute,second);
            UART_UartPutString(time);
            prev = second;
        }
    }
}

/* [] END OF FILE */
