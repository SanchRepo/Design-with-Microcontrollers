/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#define MATRIX_SIZE 15
int tc;
int elapsedTime;
int t1;
int t2;
char temp[10];

void matrixMult(float A[MATRIX_SIZE][MATRIX_SIZE],
                float B[MATRIX_SIZE][MATRIX_SIZE],
                float C[MATRIX_SIZE][MATRIX_SIZE])

{
    int8 i, j, k;
    float temp;
    for(i=0; i < MATRIX_SIZE; i++){
         for(j=0; j< MATRIX_SIZE; j++){
            temp = 0.0;
            for(k = 0; k <MATRIX_SIZE; k++){
                temp+= A[i][k] * B[k][j];
            }
            C[i][j] = temp;
          }  
       }     
}

void populateMatrix(float M[MATRIX_SIZE][MATRIX_SIZE]) {
    int8 i, j;
    for(i = 0; i < MATRIX_SIZE;i++) {
        for(j = 0; j < MATRIX_SIZE;j++) {
        M[i][j] = (float)rand()/(float)RAND_MAX;
        }
    }
}

CY_ISR(UART_Handler){
    
    UART_ClearRxInterruptSource(UART_GetRxInterruptSource());
}

CY_ISR(Timer_Handler) {
    tc=tc+1;
}

void tic(void){
    tc = 0;
    t1 = Timer_1_ReadCounter();
}

void toc(void){
    t2 = 250 - Timer_1_ReadCounter();
    elapsedTime = (t1 + t2 + 250*(tc-1))*pow(10,-3);
}

int main(void)

{
    CyGlobalIntDisable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    UART_Int_Start();
    UART_Int_SetVector(UART_Handler);
    
    Timer_Int_Start();
    Timer_Int_SetVector(Timer_Handler);
    CyGlobalIntEnable;
    
    
    UART_Start();
    Timer_1_Start();
    
    srand(rand());
    
    float A[MATRIX_SIZE][MATRIX_SIZE];
    float B[MATRIX_SIZE][MATRIX_SIZE];
    float C[MATRIX_SIZE][MATRIX_SIZE];
    
    
    
    for(;;)
    {
        populateMatrix(A);
        populateMatrix(B);
        
        tic();
        matrixMult(A, B, C);
        toc();
        sprintf(temp,"%d",elapsedTime);
        UART_UartPutString("Elapsed time: ");
        UART_UartPutString(temp);
        UART_UartPutString("ms\r\n");
        CyDelay(1000);
     }
 }


/* [] END OF FILE */
