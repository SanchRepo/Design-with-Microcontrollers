/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
int delay = 1000;
int flip = 0;

CY_ISR( Pin_SW2_Handler )
{
    CyDelay(50);
    while(!Pin_SW2_Read());
    CyDelay(50);
    if(delay == 5000) {
        flip =  -1000;
        
         
    } 
    if(delay == 1000){
        flip = 1000;
        
    }    
    
    delay = delay+flip;
    
    Pin_SW2_ClearInterrupt();
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    Pin_SW2_Int_StartEx( Pin_SW2_Handler);

    for(;;)
    {
        Pin_Red_Write( ~ Pin_Red_Read() );
        CyDelay(1000);
        Pin_Red_Write( ~ Pin_Red_Read() );
        CyDelay(delay);
    }
}

/* [] END OF FILE */
