/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
// Do 05 using a 2-bit counter instead of flipflop
#include "project.h"


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

  

    for(;;)
    {
        /*Pin_Red_Write( ~ Pin_SW2_Read() );*/
        
    }
}

/* [] END OF FILE */
