/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
CY_ISR(Timer_Int_Handler)
{
    Timer_ClearInterrupt(Timer_INTR_MASK_TC);
}    

int main()
{
    CyGlobalIntEnable;      /* Enable global interrupts */
    
  
    
    UART_Start();
    
    Timer_Int_StartEx( Timer_Int_Handler );
    
    for(;;)
    {
       UART_UartPutString( "Awake...\r\n"); 
       CyDelay( 5000 );
       UART_UartPutString( "Sleeping...\r\n");
       Timer_Start();
    
       CySysPmSleep();
    
    }
}
