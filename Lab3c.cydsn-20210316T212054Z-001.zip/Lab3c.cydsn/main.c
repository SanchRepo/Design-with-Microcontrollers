/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"


uint32 t0 = 0; 
uint32 n =  0;
uint32 rpm = 0;
uint32 t1 = 0;

char check[8];



CY_ISR(captureISR)
{
    UART_UartPutString("Beginning");   
    uint32 n = Timer_1_ReadPeriod();
    uint16 counter = Timer_1_ReadCapture();
    t1 = Timer_1_ReadCounter();
    
    uint32 elapsedCount = (t1 - t0 + 1 + n)%n;
    uint32 elapsedTime = 1/counter * elapsedCount;
    rpm = 1/(2*elapsedTime)*60; 
    
    t0=t1;
    Timer_1_ReadStatus();
    
    UART_UartPutString("Interrupt");
    
//        snprintf(check,"%02d",rpm);
//        UART_UartPutString(check);

}

CY_ISR(UART_Handler)
{
 
    
    
    
}   
int main(void)

{
    
    PWM_Start();
    UART_Start(); 
    Timer_1_Start();  
    
    CyGlobalIntEnable;; /* Enable global interrupts. */
    

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    Timer_Int_Start();
    Timer_Int_StartEx(captureISR);
    

    
    
    
    for(;;)
    {

    }
}





/* [] END OF FILE */
