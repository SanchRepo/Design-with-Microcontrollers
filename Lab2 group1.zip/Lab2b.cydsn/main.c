/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int delay = 1000;
int lock = 1;
CY_ISR( Pin_SW2_Handler )
{
    CyDelay(50);
    while(!Pin_SW2_Read());
    CyDelay(50);
    if (lock == 1) {
        lock = 0;
    }
    else {
        lock = 1;
    }
    Pin_SW2_ClearInterrupt();
}

CY_ISR(UART_Handler)
{
    uint32 rxData;
    rxData = UART_UartGetChar();
    UART_UartPutChar(rxData);
    int uartdelay = 10;
    UART_ClearRxInterruptSource(UART_GetRxInterruptMode());
    uartdelay = rxData - '0';
    if(lock == 0){
        if(uartdelay >= 1 && uartdelay <= 5) {
        delay = uartdelay*1000;
    }
    }
}

int main(void)
{
    CyGlobalIntDisable;
    Pin_SW2_Int_StartEx( Pin_SW2_Handler);
    UART_Int_Start();
    UART_Int_SetVector(UART_Handler);
    Pin_SW2_Int_SetVector(Pin_SW2_Handler);
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();

    for(;;)
    {
        Pin_Red_Write(0);
        CyDelay(1000);
        Pin_Red_Write(1);
        CyDelay(delay);
    }
}

/* [] END OF FILE */
